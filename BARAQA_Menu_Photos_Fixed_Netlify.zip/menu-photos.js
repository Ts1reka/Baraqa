/* Per-dish sources. Wikimedia media now use their officially supported redirect endpoint. */
window.BARAQA_MENU_PHOTOS = {
  "starters": [
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Georgian_cheese_in_%D0%A2bilisi_shop.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Georgian_cheese_in_%D0%A2bilisi_shop.jpg",
      "type": "wikimedia",
      "filename": "Georgian cheese in Тbilisi shop.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Georgian_cheese_in_%D0%A2bilisi_shop.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Discs-of-sulguni-cheese.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Discs-of-sulguni-cheese.jpg",
      "type": "wikimedia",
      "filename": "Discs-of-sulguni-cheese.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Discs-of-sulguni-cheese.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Mchadi_and_Imeretian_cheese.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Mchadi_and_Imeretian_cheese.jpg",
      "type": "wikimedia",
      "filename": "Mchadi and Imeretian cheese.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Mchadi_and_Imeretian_cheese.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Mzhavis_asorti_%28%E1%83%9B%E1%83%9F%E1%83%90%E1%83%95%E1%83%98%E1%83%A1_%E1%83%90%E1%83%A1%E1%83%9D%E1%83%A0%E1%83%A2%E1%83%98%29.JPG&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Mzhavis_asorti_(%E1%83%9B%E1%83%9F%E1%83%90%E1%83%95%E1%83%98%E1%83%A1_%E1%83%90%E1%83%A1%E1%83%9D%E1%83%A0%E1%83%A2%E1%83%98).JPG",
      "type": "wikimedia",
      "filename": "Mzhavis asorti (მჟავის ასორტი).JPG",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Mzhavis_asorti_%28%E1%83%9B%E1%83%9F%E1%83%90%E1%83%95%E1%83%98%E1%83%A1_%E1%83%90%E1%83%A1%E1%83%9D%E1%83%A0%E1%83%A2%E1%83%98%29.JPG"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Eggplant_with_walnut_and_pomegranate_seeds.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Eggplant_with_walnut_and_pomegranate_seeds.jpg",
      "type": "wikimedia",
      "filename": "Eggplant with walnut and pomegranate seeds.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Eggplant_with_walnut_and_pomegranate_seeds.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Ajapsandali_-_Georgian_eggplant_stew.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Ajapsandali_-_Georgian_eggplant_stew.jpg",
      "type": "wikimedia",
      "filename": "Ajapsandali - Georgian eggplant stew.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Ajapsandali_-_Georgian_eggplant_stew.jpg"
    }
  ],
  "salads": [
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Traditional_Georgian_salad.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Traditional_Georgian_salad.jpg",
      "type": "wikimedia",
      "filename": "Traditional Georgian salad.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Traditional_Georgian_salad.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Traditional_Georgian_salad_with_walnuts.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Traditional_Georgian_salad_with_walnuts.jpg",
      "type": "wikimedia",
      "filename": "Traditional Georgian salad with walnuts.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Traditional_Georgian_salad_with_walnuts.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Georgian_salad.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Georgian_salad.jpg",
      "type": "wikimedia",
      "filename": "Georgian salad.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Georgian_salad.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/A_Caesar_salad.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:A_Caesar_salad.jpg",
      "type": "wikimedia",
      "filename": "A Caesar salad.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/A_Caesar_salad.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Greek_Salad_from_Thessaloniki.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Greek_Salad_from_Thessaloniki.jpg",
      "type": "wikimedia",
      "filename": "Greek Salad from Thessaloniki.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Greek_Salad_from_Thessaloniki.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Chicken_salad_on_striped_tablecloth.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Chicken_salad_on_striped_tablecloth.jpg",
      "type": "wikimedia",
      "filename": "Chicken salad on striped tablecloth.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Chicken_salad_on_striped_tablecloth.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Mushroom_salad_2020.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Mushroom_salad_2020.jpg",
      "type": "wikimedia",
      "filename": "Mushroom salad 2020.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Mushroom_salad_2020.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Crab_and_avocado_salad.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Crab_and_avocado_salad.jpg",
      "type": "wikimedia",
      "filename": "Crab and avocado salad.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Crab_and_avocado_salad.jpg"
    }
  ],
  "soups": [
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Chicken_soup_homemade.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Chicken_soup_homemade.jpg",
      "type": "wikimedia",
      "filename": "Chicken soup homemade.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Chicken_soup_homemade.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Chikhirtma.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Chikhirtma.jpg",
      "type": "wikimedia",
      "filename": "Chikhirtma.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Chikhirtma.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Kharcho_meat_soup.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Kharcho_meat_soup.jpg",
      "type": "wikimedia",
      "filename": "Kharcho meat soup.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Kharcho_meat_soup.jpg"
    },
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Argentine_Homemade_Vegetable_Soup.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Argentine_Homemade_Vegetable_Soup.jpg",
      "type": "wikimedia",
      "filename": "Argentine Homemade Vegetable Soup.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Argentine_Homemade_Vegetable_Soup.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Mushroom_Soup.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Mushroom_Soup.jpg",
      "type": "wikimedia",
      "filename": "Mushroom Soup.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Mushroom_Soup.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Fish_soup.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Fish_soup.jpg",
      "type": "wikimedia",
      "filename": "Fish soup.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Fish_soup.jpg"
    }
  ],
  "bakery": [
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Khachapuri_1.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Khachapuri_1.jpg",
      "type": "wikimedia",
      "filename": "Khachapuri 1.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Khachapuri_1.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Adjarian_khachapuri_on_a_wooden_tray.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Adjarian_khachapuri_on_a_wooden_tray.jpg",
      "type": "wikimedia",
      "filename": "Adjarian khachapuri on a wooden tray.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Adjarian_khachapuri_on_a_wooden_tray.jpg"
    },
    null,
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Lobiani_-_bean-filled_bread.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Lobiani_-_bean-filled_bread.jpg",
      "type": "wikimedia",
      "filename": "Lobiani - bean-filled bread.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Lobiani_-_bean-filled_bread.jpg"
    },
    null,
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Megruli_Chatschapuri.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Megruli_Chatschapuri.jpg",
      "type": "wikimedia",
      "filename": "Megruli Chatschapuri.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Megruli_Chatschapuri.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Kubdari_meat_pastry.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Kubdari_meat_pastry.jpg",
      "type": "wikimedia",
      "filename": "Kubdari meat pastry.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Kubdari_meat_pastry.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Mchadi_2.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Mchadi_2.jpg",
      "type": "wikimedia",
      "filename": "Mchadi 2.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Mchadi_2.jpg"
    },
    null,
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/%D0%A8%D0%BE%D1%82%D0%B8_%D0%B3%D1%80%D1%83%D0%B7%D0%B8%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%85%D0%BB%D0%B5%D0%B1.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:%D0%A8%D0%BE%D1%82%D0%B8_%D0%B3%D1%80%D1%83%D0%B7%D0%B8%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%85%D0%BB%D0%B5%D0%B1.jpg",
      "type": "wikimedia",
      "filename": "Шоти грузинский хлеб.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/%D0%A8%D0%BE%D1%82%D0%B8_%D0%B3%D1%80%D1%83%D0%B7%D0%B8%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%85%D0%BB%D0%B5%D0%B1.jpg"
    }
  ],
  "pizza": [
    null,
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Pizza_Margherita.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Pizza_Margherita.jpg",
      "type": "wikimedia",
      "filename": "Pizza Margherita.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Pizza_Margherita.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Vege_pizza.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Vege_pizza.jpg",
      "type": "wikimedia",
      "filename": "Vege pizza.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Vege_pizza.jpg"
    }
  ],
  "mains": [
    {
      "url": "assets/food-khinkali.webp",
      "source": "",
      "type": "baraqa"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Khinkali_cheese.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Khinkali_cheese.jpg",
      "type": "wikimedia",
      "filename": "Khinkali cheese.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Khinkali_cheese.jpg"
    },
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Chashushuli_01.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Chashushuli_01.jpg",
      "type": "wikimedia",
      "filename": "Chashushuli 01.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Chashushuli_01.jpg"
    },
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Ojakhuri.JPG&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Ojakhuri.JPG",
      "type": "wikimedia",
      "filename": "Ojakhuri.JPG",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Ojakhuri.JPG"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Odjakhuri_-_Georgian_%28Kartvelian%29_dish_with_meat._Served_in_Galaktioni_restaurant_Istanbul.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Odjakhuri_-_Georgian_(Kartvelian)_dish_with_meat._Served_in_Galaktioni_restaurant_Istanbul.jpg",
      "type": "wikimedia",
      "filename": "Odjakhuri - Georgian (Kartvelian) dish with meat. Served in Galaktioni restaurant Istanbul.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Odjakhuri_-_Georgian_%28Kartvelian%29_dish_with_meat._Served_in_Galaktioni_restaurant_Istanbul.jpg"
    },
    null,
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Chakhokhbili_Closeup.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Chakhokhbili_Closeup.jpg",
      "type": "wikimedia",
      "filename": "Chakhokhbili Closeup.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Chakhokhbili_Closeup.jpg"
    },
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Georgian_Cheese-Stuffed_Mushrooms.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Georgian_Cheese-Stuffed_Mushrooms.jpg",
      "type": "wikimedia",
      "filename": "Georgian Cheese-Stuffed Mushrooms.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Georgian_Cheese-Stuffed_Mushrooms.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Homemade_beef_tongue.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Homemade_beef_tongue.jpg",
      "type": "wikimedia",
      "filename": "Homemade beef tongue.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Homemade_beef_tongue.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Chicken_tabaka.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Chicken_tabaka.jpg",
      "type": "wikimedia",
      "filename": "Chicken tabaka.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Chicken_tabaka.jpg"
    },
    {
      "url": "assets/hero-chicken.webp",
      "source": "",
      "type": "baraqa"
    },
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Kupati_%28%E1%83%99%E1%83%A3%E1%83%9E%E1%83%90%E1%83%A2%E1%83%98%29.JPG&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Kupati_(%E1%83%99%E1%83%A3%E1%83%9E%E1%83%90%E1%83%A2%E1%83%98).JPG",
      "type": "wikimedia",
      "filename": "Kupati (კუპატი).JPG",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Kupati_%28%E1%83%99%E1%83%A3%E1%83%9E%E1%83%90%E1%83%A2%E1%83%98%29.JPG"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Satsivi_%282%29.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Satsivi_(2).jpg",
      "type": "wikimedia",
      "filename": "Satsivi (2).jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Satsivi_%282%29.jpg"
    },
    null,
    null,
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Breakfast_Omelette.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Breakfast_Omelette.jpg",
      "type": "wikimedia",
      "filename": "Breakfast Omelette.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Breakfast_Omelette.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Lobio_in_clay_pots_covered_with_mchadi.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Lobio_in_clay_pots_covered_with_mchadi.jpg",
      "type": "wikimedia",
      "filename": "Lobio in clay pots covered with mchadi.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Lobio_in_clay_pots_covered_with_mchadi.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Ghomi_with_Georgian_Cheese_Sulguni.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Ghomi_with_Georgian_Cheese_Sulguni.jpg",
      "type": "wikimedia",
      "filename": "Ghomi with Georgian Cheese Sulguni.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Ghomi_with_Georgian_Cheese_Sulguni.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Elarji_-_cornmeal_and_sulguni_cheese.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Elarji_-_cornmeal_and_sulguni_cheese.jpg",
      "type": "wikimedia",
      "filename": "Elarji - cornmeal and sulguni cheese.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Elarji_-_cornmeal_and_sulguni_cheese.jpg"
    },
    null,
    null,
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Next_Door_roasted_veggie_salad_with_salmon.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Next_Door_roasted_veggie_salad_with_salmon.jpg",
      "type": "wikimedia",
      "filename": "Next Door roasted veggie salad with salmon.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Next_Door_roasted_veggie_salad_with_salmon.jpg"
    }
  ],
  "grill": [
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Ghoris_Mtsvadi_%28%E1%83%A6%E1%83%9D%E1%83%A0%E1%83%98%E1%83%A1_%E1%83%9B%E1%83%AC%E1%83%95%E1%83%90%E1%83%93%E1%83%98%29.JPG&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Ghoris_Mtsvadi_(%E1%83%A6%E1%83%9D%E1%83%A0%E1%83%98%E1%83%A1_%E1%83%9B%E1%83%AC%E1%83%95%E1%83%90%E1%83%93%E1%83%98).JPG",
      "type": "wikimedia",
      "filename": "Ghoris Mtsvadi (ღორის მწვადი).JPG",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Ghoris_Mtsvadi_%28%E1%83%A6%E1%83%9D%E1%83%A0%E1%83%98%E1%83%A1_%E1%83%9B%E1%83%AC%E1%83%95%E1%83%90%E1%83%93%E1%83%98%29.JPG"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Chicken_Mtsvadi_and_Fried_Piglet.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Chicken_Mtsvadi_and_Fried_Piglet.jpg",
      "type": "wikimedia",
      "filename": "Chicken Mtsvadi and Fried Piglet.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Chicken_Mtsvadi_and_Fried_Piglet.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Grilled_salmon_garnished_with_lemon_and_parsley.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Grilled_salmon_garnished_with_lemon_and_parsley.jpg",
      "type": "wikimedia",
      "filename": "Grilled salmon garnished with lemon and parsley.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Grilled_salmon_garnished_with_lemon_and_parsley.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Grilled_vegetables_%282%29.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Grilled_vegetables_(2).jpg",
      "type": "wikimedia",
      "filename": "Grilled vegetables (2).jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Grilled_vegetables_%282%29.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Mtsvadi.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Mtsvadi.jpg",
      "type": "wikimedia",
      "filename": "Mtsvadi.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Mtsvadi.jpg"
    },
    null
  ],
  "sides": [
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Cooked_Rice_2.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Cooked_Rice_2.jpg",
      "type": "wikimedia",
      "filename": "Cooked Rice 2.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Cooked_Rice_2.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/French_Fries.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:French_Fries.jpg",
      "type": "wikimedia",
      "filename": "French Fries.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/French_Fries.jpg"
    },
    {
      "url": "assets/food-potatoes.webp",
      "source": "",
      "type": "baraqa"
    }
  ],
  "sauces": [
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Tkemali_2.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Tkemali_2.jpg",
      "type": "wikimedia",
      "filename": "Tkemali 2.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Tkemali_2.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Pasta_sauce_in_a_bowl.webp&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Pasta_sauce_in_a_bowl.webp",
      "type": "wikimedia",
      "filename": "Pasta sauce in a bowl.webp",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Pasta_sauce_in_a_bowl.webp"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Megrelian_ajika.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Megrelian_ajika.jpg",
      "type": "wikimedia",
      "filename": "Megrelian ajika.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Megrelian_ajika.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Sour_Cream.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Sour_Cream.jpg",
      "type": "wikimedia",
      "filename": "Sour Cream.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Sour_Cream.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Satsivi_al_Batumi_Val%C3%A8ncia.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Satsivi_al_Batumi_Val%C3%A8ncia.jpg",
      "type": "wikimedia",
      "filename": "Satsivi al Batumi València.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Satsivi_al_Batumi_Val%C3%A8ncia.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Mayonnaise_in_the_bowl.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Mayonnaise_in_the_bowl.jpg",
      "type": "wikimedia",
      "filename": "Mayonnaise in the bowl.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Mayonnaise_in_the_bowl.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Homemade_ketchup_canned_%284156502791%29.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Homemade_ketchup_canned_(4156502791).jpg",
      "type": "wikimedia",
      "filename": "Homemade ketchup canned (4156502791).jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Homemade_ketchup_canned_%284156502791%29.jpg"
    }
  ],
  "desserts": [
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Chocolate_crepe_layered_with_chocolate_mousse_with_puffed_sorghum_and_molasses_syrup_%2818705305753%29.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Chocolate_crepe_layered_with_chocolate_mousse_with_puffed_sorghum_and_molasses_syrup_(18705305753).jpg",
      "type": "wikimedia",
      "filename": "Chocolate crepe layered with chocolate mousse with puffed sorghum and molasses syrup (18705305753).jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Chocolate_crepe_layered_with_chocolate_mousse_with_puffed_sorghum_and_molasses_syrup_%2818705305753%29.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Banana_%2B_Chocolate_cr%C3%AApe_%40_Breakfast_%40_Le_Resto_du_Village_%40_Montr%C3%A9al_%2830461563936%29.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Banana_%2B_Chocolate_cr%C3%AApe_%40_Breakfast_%40_Le_Resto_du_Village_%40_Montr%C3%A9al_(30461563936).jpg",
      "type": "wikimedia",
      "filename": "Banana + Chocolate crêpe @ Breakfast @ Le Resto du Village @ Montréal (30461563936).jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Banana_%2B_Chocolate_cr%C3%AApe_%40_Breakfast_%40_Le_Resto_du_Village_%40_Montr%C3%A9al_%2830461563936%29.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Veselka-nalysnyky-20250309_195201.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Veselka-nalysnyky-20250309_195201.jpg",
      "type": "wikimedia",
      "filename": "Veselka-nalysnyky-20250309 195201.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Veselka-nalysnyky-20250309_195201.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/2013-365-222_Mmmmm_Pie_%289481459925%29.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:2013-365-222_Mmmmm_Pie_(9481459925).jpg",
      "type": "wikimedia",
      "filename": "2013-365-222 Mmmmm Pie (9481459925).jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/2013-365-222_Mmmmm_Pie_%289481459925%29.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/Dipper_stick_and_honey_in_a_jar.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:Dipper_stick_and_honey_in_a_jar.jpg",
      "type": "wikimedia",
      "filename": "Dipper stick and honey in a jar.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/Dipper_stick_and_honey_in_a_jar.jpg"
    },
    {
      "url": "https://commons.wikimedia.org/w/index.php?title=Special:Redirect/file/20220727-_pic_of_double_icecream_with_chocolate_and_vanilla.jpg&width=720",
      "source": "https://commons.wikimedia.org/wiki/File:20220727-_pic_of_double_icecream_with_chocolate_and_vanilla.jpg",
      "type": "wikimedia",
      "filename": "20220727- pic of double icecream with chocolate and vanilla.jpg",
      "backupUrl": "https://commons.wikimedia.org/wiki/Special:FilePath/20220727-_pic_of_double_icecream_with_chocolate_and_vanilla.jpg"
    }
  ]
};
