(() => {
  'use strict';
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const getStored = key => { try { return localStorage.getItem(key); } catch { return null; } };
  const setStored = (key, value) => { try { localStorage.setItem(key, value); } catch {} };

  // Reservations: update this number once if Baraqa's phone number changes.
  // A tel: link opens the device's native dialer; the visitor confirms the call.
  const BOOKING_PHONE = '+995599192626';
  const BOOKING_DISPLAY_PHONE = '+995 599 192 626';
  $$('[data-booking-call]').forEach(link => {
    link.href = `tel:${BOOKING_PHONE}`;
  });
  $('#bookingPhoneNumber').href = `tel:${BOOKING_PHONE}`;
  $('#bookingPhoneNumber').textContent = BOOKING_DISPLAY_PHONE;

  const translations = {
    ka: {
      navAbout:'ჩვენ შესახებ',navMenu:'მენიუ',navSpaces:'სივრცეები',navGallery:'გალერეა',navContact:'კონტაქტი',reserve:'დაჯავშნა',callNow:'დაგვიკავშირდით',
      heroTag:'კეთილი იყოს თქვენი მობრძანება',heroTitle:'გემო, რომელიც<br>გულში <em>რჩება.</em>',heroSubtitle:'ნამდვილი ქართული კერძები, ტრადიციული რეცეპტები და მასპინძლობა, რომელსაც ყოველთვის დაუბრუნდებით.',exploreMenu:'აღმოაჩინეთ მენიუ',seeSpaces:'იხილეთ სივრცეები',heroCity:'ქუთაისი, საქართველო',heroAddress:'თამარ მეფის ქუჩა 7',scrollDown:'ჩამოსქროლეთ',
      aboutKicker:'ჩვენი ისტორია',aboutHeading:'აქ ყოველი სტუმარი<br><em>ჩვენიანია.</em>',aboutLead:'ქუთაისის გულში არის ადგილი, სადაც ქართული სუფრის ტრადიცია ყოველდღე ცოცხლდება.',aboutBody:'„ბარაქაში“ ერთმანეთს ხვდება ნაცნობი გემოები, გულით მომზადებული კერძები და მშვიდი, თბილი გარემო. მოდით ოჯახთან, მეგობრებთან ან უბრალოდ კარგი კერძის სიყვარულით — ჩვენი კარი ყოველთვის ღიაა.',visitUs:'გვეწვიეთ ბარაქაში',
      highlightsKicker:'ჩვენი სამზარეულოდან',highlightsHeading:'გემოები, რომლებსაც<br><em>შეიყვარებთ.</em>',fullMenu:'სრული მენიუ',traditional:'ტრადიციული',houseFavorite:'საყვარელი კერძი',georgianCuisine:'ქართული სამზარეულო',foodKhinkali:'ხინკალი',foodChkmeruli:'შქმერული',foodChicken:'შემწვარი ქათამი',perPiece:'/ ც.',
      menuKicker:'შეარჩიეთ თქვენი გემო',menuHeading:'ჩვენი <em>მენიუ.</em>',menuIntro:'ტრადიციული ქართული კერძებიდან საყვარელ სასმელებამდე — ყველაფერი ერთ ადგილას.',currencyNote:'ყველა ფასი ლარშია',searchPlaceholder:'მოძებნეთ კერძი...',menuEyebrow:'BARAQA / კერძები და სასმელები',noResults:'კერძი ვერ მოიძებნა. სცადეთ სხვა დასახელება.',serviceCharge:'ფასებს ემატება 10% მომსახურების საფასური.',menuDisclaimer:'ზოგი ფასი დასაზუსტებელია.',menuPhotoNote:'საკვების ფოტოები საილუსტრაციოა და შეიძლება განსხვავდებოდეს ადგილზე მომზადებული კერძებისგან.',featured:'რჩეული კერძები',all:'ყველა',itemCount:n=>`${n} დასახელება`,priceOnRequest:'ფასი დასაზუსტებელია',
      interludeKicker:'ქართული სუფრის სულისკვეთება',interludeText:'კარგი საკვები ერთად ყოფნის<br><em>საუკეთესო მიზეზია.</em>',
      spacesKicker:'აღმოაჩინეთ ჩვენი გარემო',spacesHeading:'სივრცე, რომელიც<br><em>თქვენ გელოდებათ.</em>',spacesIntro:'ყოველ კუთხეს თავისი ხასიათი აქვს — აირჩიეთ ადგილი, სადაც თქვენი საღამო განსაკუთრებული იქნება.',space1Title:'თბილი ინტერიერი',space1Desc:'ხის დეტალები, ტრადიციული ხასიათი და მყუდრო სუფრა.',space2Title:'ქართული ეზო',space2Desc:'მწვანე კუთხე და ღია ცის ქვეშ გატარებული საღამოები.',space3Title:'ბარის სივრცე',space3Desc:'თბილი განათება და სასიამოვნო გარემო სასაუბროდ.',
      galleryKicker:'ჩვენი მომენტები',galleryHeading:'გაიცანით <em>ბარაქა.</em>',galleryIntro:'ერთი ფოტო — ათასი გემო, ისტორია და დასამახსოვრებელი მომენტი.',
      contactKicker:'გელოდებით ბარაქაში',contactHeading:'მოდი, ერთად<br><em>გავიზიაროთ გემო.</em>',contactIntro:'გეგმავთ ოჯახურ ვახშამს, მეგობრებთან შეხვედრას ან უბრალოდ გსურთ ქართული კერძების დაგემოვნება? დაგვიკავშირდით.',addressLabel:'მისამართი',addressText:'თამარ მეფის ქუჩა 7, ქუთაისი',phoneLabel:'ტელეფონი',emailLabel:'ელ. ფოსტა',reserveTable:'დაჯავშნეთ მაგიდა',getDirections:'როგორ მოვიდეთ',hoursNote:'სამუშაო საათების დასაზუსტებლად დაგვიკავშირდით.',findUs:'გვიპოვეთ ქუთაისის ცენტრში',footerTagline:'კარგი გემო.<br>თბილი შეხვედრები.<br><em>ბარაქიანი დღეები.</em>',rights:'ყველა უფლება დაცულია.',backTop:'ზემოთ ↑',
      reserveByPhone:'დაჯავშნეთ ტელეფონით',bookingEyebrow:'მაგიდის დაჯავშნა',bookingTitle:'დაჯავშნეთ მაგიდა <em>ბარაქაში.</em>',bookingDescription:'მაგიდის დასაჯავშნად დაგვიკავშირდით ქვემოთ მითითებულ ნომერზე. ჩვენი გუნდი სიამოვნებით დაგეხმარებათ.',bookingPhoneLabel:'დაგვირეკეთ ნომერზე',bookingCopy:'ნომრის კოპირება',bookingCopied:'ნომერი დაკოპირებულია!',bookingCallAction:'დარეკვა',bookingTip:'შეგიძლიათ ნომერი დააკოპიროთ და დარეკოთ თქვენი ტელეფონიდან.',bookingLocation:'თამარ მეფის ქუჩა 7 · ქუთაისი',bookingClose:'დახურვა'
    },
    en: {
      navAbout:'About us',navMenu:'Our menu',navSpaces:'Our spaces',navGallery:'Gallery',navContact:'Contact',reserve:'Reserve',callNow:'Call us',
      heroTag:'A warm Georgian welcome',heroTitle:'A taste that<br><em>stays with you.</em>',heroSubtitle:'Authentic Georgian dishes, cherished recipes, and the kind of hospitality that makes you want to return.',exploreMenu:'Explore our menu',seeSpaces:'Discover our spaces',heroCity:'Kutaisi, Georgia',heroAddress:'7 Tamar Mepe Street',scrollDown:'Scroll to explore',
      aboutKicker:'Our story',aboutHeading:'Come as a guest.<br><em>Leave as family.</em>',aboutLead:'In the heart of Kutaisi, there is a place where the Georgian table comes to life every day.',aboutBody:'At Baraqa, familiar flavors meet lovingly prepared food and an inviting atmosphere. Come with family, bring your friends, or simply follow your love of good food. There is always a place for you at our table.',visitUs:'Come visit Baraqa',
      highlightsKicker:'From our kitchen',highlightsHeading:'Flavors worth<br><em>falling for.</em>',fullMenu:'View full menu',traditional:'Traditional favorite',houseFavorite:'House favorite',georgianCuisine:'Georgian cuisine',foodKhinkali:'Khinkali',foodChkmeruli:'Chkmeruli',foodChicken:'Fried chicken',perPiece:'/ pc',
      menuKicker:'Find your favorite',menuHeading:'Our <em>menu.</em>',menuIntro:'From beloved Georgian classics to refreshing drinks — something for every appetite.',currencyNote:'All prices in GEL',searchPlaceholder:'Search for a dish...',menuEyebrow:'BARAQA / FOOD & DRINKS',noResults:'No dishes found. Try a different search.',serviceCharge:'A 10% service charge is added to the listed prices.',menuDisclaimer:'Some prices need confirmation.',menuPhotoNote:'Food photos are illustrative and may differ from dishes served at the restaurant.',featured:'Our favorites',all:'All',itemCount:n=>`${n} items`,priceOnRequest:'Ask for price',
      interludeKicker:'The spirit of the Georgian table',interludeText:'Good food tastes better<br><em>when shared.</em>',
      spacesKicker:'Discover our atmosphere',spacesHeading:'Find your<br><em>favorite corner.</em>',spacesIntro:'Every corner has its own character. Find the perfect setting for your next memorable meal.',space1Title:'Cozy interiors',space1Desc:'Rustic textures, welcoming warmth, and a table worth gathering around.',space2Title:'Georgian courtyard',space2Desc:'A green retreat and relaxed evenings under the open sky.',space3Title:'Our bar',space3Desc:'Warm lighting and an inviting place to unwind.',
      galleryKicker:'Moments at Baraqa',galleryHeading:'Inside <em>Baraqa.</em>',galleryIntro:'A glimpse of the food, faces and places that make our restaurant special.',
      contactKicker:'We look forward to seeing you',contactHeading:'Come share<br><em>a memorable meal.</em>',contactIntro:'Planning a family dinner, meeting friends, or craving authentic Georgian food? We would love to hear from you.',addressLabel:'Address',addressText:'7 Tamar Mepe Street, Kutaisi',phoneLabel:'Phone',emailLabel:'Email',reserveTable:'Call to reserve',getDirections:'Get directions',hoursNote:'Please call us to confirm opening hours.',findUs:'Find us in central Kutaisi',footerTagline:'Good food.<br>Warm welcomes.<br><em>Beautiful memories.</em>',rights:'All rights reserved.',backTop:'Back to top ↑',
      reserveByPhone:'Book by phone',bookingEyebrow:'Table reservations',bookingTitle:'Reserve your table <em>at Baraqa.</em>',bookingDescription:'To reserve a table, please call the number below. Our team will be happy to assist you.',bookingPhoneLabel:'Call us on',bookingCopy:'Copy number',bookingCopied:'Number copied!',bookingCallAction:'Call now',bookingTip:'You can copy our number and call us from your phone.',bookingLocation:'7 Tamar Mepe Street · Kutaisi',bookingClose:'Close'
    }
  };

  let language = getStored('baraqa-language') === 'en' ? 'en' : 'ka';
  let theme = getStored('baraqa-theme') === 'dark' ? 'dark' : 'light';
  let activeCategory = 'featured';
  let menuReady = false;
  let activePhoto = 0;
  let heroSlide = 0;
  let timer;
  const loader = $('#loader');
  const welcome = $('#welcome');
  const galleryButtons = $$('.gallery-cell');

  function applyTheme(next) {
    theme = next;
    document.body.dataset.theme = next;
    $('#themeToggle').setAttribute('aria-label',next === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
    setStored('baraqa-theme',next);
  }
  function applyLanguage(next) {
    language = next;
    document.documentElement.lang = next;
    document.title = next === 'ka' ? 'BARAQA — ქართული გემო ქუთაისის გულში' : 'BARAQA — Georgian cuisine in Kutaisi';
    $('#languageLabel').textContent = next === 'ka' ? 'GE' : 'EN';
    const copy = translations[next];
    $$('[data-i18n]').forEach(el => {const val = copy[el.dataset.i18n]; if (typeof val === 'string') el.textContent=val;});
    $$('[data-i18n-html]').forEach(el => {const val = copy[el.dataset.i18nHtml]; if (typeof val === 'string') el.innerHTML=val;});
    $$('[data-i18n-placeholder]').forEach(el => {const val = copy[el.dataset.i18nPlaceholder]; if (typeof val === 'string') el.placeholder=val;});
    $('#langPopover').hidden=true;
    $('#bookingTitle').innerHTML=copy.bookingTitle;
    $('#bookingClose').setAttribute('aria-label',copy.bookingClose);
    $('#bookingCopyLabel').textContent=copy.bookingCopy;
    $('.mobile-booking-bar').setAttribute('aria-label',copy.reserveByPhone);
    if (menuReady) renderMenu();
    if (!$('#lightbox').hidden) updateLightbox();
    setStored('baraqa-language',next);
  }
  function closeWelcome(next) {
    applyLanguage(next);
    welcome.classList.remove('show');
    welcome.setAttribute('aria-hidden','true');
    document.body.classList.remove('dialog-open');
  }
  applyTheme(theme);
  applyLanguage(language);

  // Initial sequence: short brand animation, then choose language once.
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
      if (!getStored('baraqa-language-chosen')) {
        welcome.classList.add('show');
        welcome.setAttribute('aria-hidden','false');
        document.body.classList.add('dialog-open');
      }
      loader.classList.add('done');
    }, 1300);
  });
  $$('[data-choose-language]').forEach(button => button.addEventListener('click', () => {
    setStored('baraqa-language-chosen','yes');
    closeWelcome(button.dataset.chooseLanguage);
  }));
  $$('[data-set-language]').forEach(button => button.addEventListener('click', () => applyLanguage(button.dataset.setLanguage)));
  $('#languageToggle').addEventListener('click', event => { event.stopPropagation(); $('#langPopover').hidden=!$('#langPopover').hidden; });
  $('#themeToggle').addEventListener('click', () => applyTheme(theme==='light'?'dark':'light'));
  document.addEventListener('click', event=>{if (!event.target.closest('#langPopover')&&!event.target.closest('#languageToggle')) $('#langPopover').hidden=true;});

  // Booking behaviour: phone browsers use native dialling, computers see a helpful modal.
  // A narrow desktop window stays a desktop. This tests device capabilities/UA,
  // rather than simply treating all small browser windows as phones.
  const bookingDialog = $('#bookingDialog');
  const bookingClose = $('#bookingClose');
  const bookingCopy = $('#bookingCopy');
  let bookingOpener = null;
  let copyFeedbackTimeout;
  const mobileDevice = () => /Android|iPhone|iPad|iPod|Mobile|Windows Phone/i.test(navigator.userAgent) || navigator.userAgentData?.mobile === true;

  function showBookingDialog(opener) {
    bookingOpener = opener;
    $('#langPopover').hidden = true;
    bookingDialog.hidden = false;
    document.body.classList.add('dialog-open');
    bookingClose.focus();
  }
  function closeBookingDialog() {
    if (bookingDialog.hidden) return;
    bookingDialog.hidden = true;
    document.body.classList.remove('dialog-open');
    clearTimeout(copyFeedbackTimeout);
    $('#bookingCopyLabel').textContent = translations[language].bookingCopy;
    bookingOpener?.focus();
  }
  $$('[data-booking-call]').forEach(link => link.addEventListener('click', event => {
    if (mobileDevice()) return; // Mobile: let the real tel: link open the dialer.
    event.preventDefault();
    showBookingDialog(link);
  }));
  bookingClose.addEventListener('click', closeBookingDialog);
  bookingDialog.addEventListener('click', event => { if (event.target === bookingDialog) closeBookingDialog(); });
  bookingCopy.addEventListener('click', async () => {
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(BOOKING_DISPLAY_PHONE);
      else {
        const field = document.createElement('textarea');
        field.value = BOOKING_DISPLAY_PHONE;
        field.style.cssText='position:fixed;opacity:0;pointer-events:none';
        document.body.appendChild(field);
        field.select();
        const copied = document.execCommand('copy');
        field.remove();
        if (!copied) throw new Error('copy failed');
      }
      $('#bookingCopyLabel').textContent=translations[language].bookingCopied;
      clearTimeout(copyFeedbackTimeout);
      copyFeedbackTimeout=setTimeout(()=>$('#bookingCopyLabel').textContent=translations[language].bookingCopy,2400);
    } catch {
      // Phone remains selectable in the dialog if the clipboard is unavailable.
      const range = document.createRange();
      range.selectNodeContents($('#bookingPhoneNumber'));
      window.getSelection()?.removeAllRanges();
      window.getSelection()?.addRange(range);
    }
  });
  bookingDialog.addEventListener('keydown', event => {
    if (event.key !== 'Tab') return;
    const focusables = $$('button:not([disabled]), a[href]',bookingDialog);
    const first=focusables[0], last=focusables[focusables.length-1];
    if (event.shiftKey && document.activeElement === first){event.preventDefault();last.focus();}
    else if (!event.shiftKey && document.activeElement === last){event.preventDefault();first.focus();}
  });

  // Mobile nav and sticky header.
  const header=$('#header');
  const mobileToggle=$('#mobileToggle');
  const mobileNav=$('#mobileNav');
  function closeMobile(){mobileNav.hidden=true;mobileToggle.setAttribute('aria-expanded','false');}
  mobileToggle.addEventListener('click',()=>{mobileNav.hidden=!mobileNav.hidden;mobileToggle.setAttribute('aria-expanded',String(!mobileNav.hidden));});
  $$('.mobile-nav a').forEach(a=>a.addEventListener('click',closeMobile));
  document.addEventListener('scroll',()=>header.classList.toggle('is-scrolled',window.scrollY>35),{passive:true});
  header.classList.toggle('is-scrolled',window.scrollY>35);
  $('#copyrightYear').textContent=new Date().getFullYear();
  $('#backToTop').addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));

  // Hero slideshow.
  const slides=$$('.hero-photo');
  function showSlide(index){heroSlide=(index+slides.length)%slides.length;slides.forEach((el,i)=>el.classList.toggle('active',i===heroSlide));$('#slideIndex').textContent=String(heroSlide+1).padStart(2,'0')+' / '+String(slides.length).padStart(2,'0');}
  function restartSlideshow(){clearInterval(timer);timer=setInterval(()=>showSlide(heroSlide+1),7200);}
  $('#prevSlide').addEventListener('click',()=>{showSlide(heroSlide-1);restartSlideshow();});
  $('#nextSlide').addEventListener('click',()=>{showSlide(heroSlide+1);restartSlideshow();});
  if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) restartSlideshow();

  // Digital menu from supplied printed menu photos.
  const menu=window.BARAQA_MENU || [];
  const favorites=[['bakery',6],['mains',0],['mains',14],['grill',4],['soups',2],['salads',0],['desserts',0],['soft',6]];
  const tabs=$('#menuTabs');
  const menuItems=$('#menuItems');
  const menuSearch=$('#menuSearch');
  // Photo selections are tied to specific Commons file pages. An unmatched item has NO
  // unrelated fallback photograph. Cards also link to photographer/source pages.
  const photoMap=window.BARAQA_MENU_PHOTOS||{};
  function allItems() {return menu.flatMap(category=>category.items.map((item,index)=>({item,category,index})));}
  function favoritesItems(){return favorites.map(([id,index])=>{const category=menu.find(c=>c.id===id);return category?.items[index]?{category,item:category.items[index],index}:null;}).filter(Boolean);}
  function dishImageUrl(item,category,index){
    return (photoMap[category.id] && photoMap[category.id][index]) || null;
  }
  function formatPrice(value){
    if (value===null) return `<span class="menu-item-price unset">${translations[language].priceOnRequest}</span>`;
    const formatted=Number(value).toLocaleString(language==='ka'?'ka-GE':'en-US',{maximumFractionDigits:2,minimumFractionDigits:Number.isInteger(value)?0:2});
    return `<span class="menu-item-price">${formatted} ₾</span>`;
  }
  function renderMenu(){
    if (!tabs || !menuItems) return;
    tabs.replaceChildren();
    [{id:'featured',ka:'რჩეული',en:'Featured'},...menu].forEach(category=>{
      const btn=document.createElement('button');btn.type='button';btn.className='menu-tab'+(activeCategory===category.id?' active':'');btn.textContent=category[language];btn.setAttribute('aria-pressed',String(activeCategory===category.id));
      btn.addEventListener('click',()=>{activeCategory=category.id;menuSearch.value='';renderMenu();});tabs.appendChild(btn);
    });
    const search=menuSearch.value.trim().toLocaleLowerCase();
    let items=search ? allItems().filter(({item})=>[item[0],item[1],item[3],item[4]].some(s=>typeof s==='string'&&s.toLocaleLowerCase().includes(search))) :
      activeCategory==='featured'?favoritesItems():allItems().filter(({category})=>category.id===activeCategory);
    const category=menu.find(cat=>cat.id===activeCategory);
    $('#activeMenuTitle').textContent=search?(language==='ka'?'ძიების შედეგები':'Search results'):(category?category[language]:translations[language].featured);
    $('#menuCount').textContent=translations[language].itemCount(items.length);
    menuItems.replaceChildren();
    const fragment=document.createDocumentFragment();
    items.forEach(({item,category,index})=>{
      const box=document.createElement('article');box.className='menu-item-card';
      const desc=item[language==='ka'?3:4]||'';
      const imageMeta=dishImageUrl(item,category,index);
      const name=item[language==='ka'?0:1];
      const imageLabel=language==='ka'?'საილუსტრაციო ფოტო · წყარო':'Illustrative photo · source';
      const absentLabel=language==='ka'?'ამ კერძის ფოტო ჯერ არ არის დამატებული':'Photo of this dish coming soon';
      const illustrative=language==='ka'?'საილუსტრაციო ფოტო':'Illustrative photo';
      const isFood=!['soft','coffee','tea','beer'].includes(category.id);
      const media=document.createElement('div');media.className='menu-item-visual';
      const frame=document.createElement('div');frame.className='menu-item-image-wrap';
      if(imageMeta){
        const img=document.createElement('img');img.className='menu-item-image';img.loading='lazy';img.decoding='async';img.alt=name;
        let photoAttempt=0;
        // First: Wikimedia's documented redirect endpoint. Second: the unscaled file URL.
        // If both are unavailable, keep a polished, dish-specific illustration without a broken-image icon.
        img.addEventListener('error',()=>{
          if(photoAttempt===0 && imageMeta.backupUrl){
            photoAttempt=1;
            img.src=imageMeta.backupUrl;
            return;
          }
          frame.classList.add('menu-photo-missing');
          img.remove();
          const place=document.createElement('div');place.className='photo-absent photo-illustration';
          const plate=document.createElement('div');plate.className='food-illustration-plate';
          plate.innerHTML='<span class="food-illustration-garnish">✦</span>';
          const title=document.createElement('div');title.className='food-illustration-name';title.textContent=name;
          place.append(plate,title);frame.appendChild(place);
        });
        img.src=imageMeta.url;
        frame.appendChild(img);
      } else {
        frame.classList.add('menu-photo-missing');
        const placeholder=document.createElement('div');placeholder.className='photo-absent photo-illustration';
        const plate=document.createElement('div');plate.className='food-illustration-plate';
        plate.innerHTML='<span class="food-illustration-garnish">✦</span>';
        const label=document.createElement('div');label.className='food-illustration-name';label.textContent=name;
        placeholder.append(plate,label);frame.appendChild(placeholder);
      }
      media.appendChild(frame);
      const categoryPill=document.createElement('div');categoryPill.className='menu-item-category';categoryPill.textContent=category[language];media.appendChild(categoryPill);
      const content=document.createElement('div');content.className='menu-item-body';
      const top=document.createElement('div');top.className='menu-item-top';
      const heading=document.createElement('h4');heading.className='menu-item-title';heading.textContent=name;
      const price=document.createElement('span');price.className='menu-item-price';
      if(item[2]===null){price.textContent=translations[language].priceOnRequest;price.classList.add('unset');}
      else price.textContent=Number(item[2]).toLocaleString(language==='ka'?'ka-GE':'en-US',{maximumFractionDigits:2,minimumFractionDigits:Number.isInteger(item[2])?0:2})+' ₾';
      top.append(heading,price);content.appendChild(top);
      if(desc){const paragraph=document.createElement('p');paragraph.className='menu-item-desc';paragraph.textContent=desc;content.appendChild(paragraph);}
      const footer=document.createElement('div');footer.className='menu-item-footer';
      if(imageMeta && imageMeta.source){
        const credit=document.createElement('a');credit.className='menu-photo-credit';credit.href=imageMeta.source;credit.target='_blank';credit.rel='noopener noreferrer';
        credit.textContent=imageLabel+' ↗';credit.title=illustrative;footer.appendChild(credit);
      } else {
        const chip=document.createElement('span');chip.className='menu-item-chip';chip.textContent='BARAQA';footer.appendChild(chip);
      }
      content.appendChild(footer);box.append(media,content);
      fragment.appendChild(box);
    });
    menuItems.appendChild(fragment);
    $('#noResults').hidden=items.length!==0;
  }
  menuSearch.addEventListener('input',renderMenu);
  menuReady = true;
  renderMenu();

  // Photo lightbox with previous/next and keyboard navigation.
  const lightbox=$('#lightbox');
  function updateLightbox(){const el=galleryButtons[activePhoto];$('#lightboxImage').src=el.dataset.image;$('#lightboxImage').alt=el.querySelector('img').alt;$('#lightboxCaption').textContent=el.dataset[language==='ka'?'captionKa':'captionEn'];}
  function showLightbox(index){activePhoto=(index+galleryButtons.length)%galleryButtons.length;updateLightbox();lightbox.hidden=false;document.body.classList.add('dialog-open');$('#closeLightbox').focus();}
  function closeLightbox(){lightbox.hidden=true;document.body.classList.remove('dialog-open');galleryButtons[activePhoto].focus();}
  galleryButtons.forEach((btn,index)=>btn.addEventListener('click',()=>showLightbox(index)));
  $('#closeLightbox').addEventListener('click',closeLightbox);
  $('#lightboxPrev').addEventListener('click',()=>{activePhoto=(activePhoto-1+galleryButtons.length)%galleryButtons.length;updateLightbox();});
  $('#lightboxNext').addEventListener('click',()=>{activePhoto=(activePhoto+1)%galleryButtons.length;updateLightbox();});
  lightbox.addEventListener('click',event=>{if(event.target===lightbox)closeLightbox();});
  document.addEventListener('keydown',event=>{
    if (event.key==='Escape') {if(!bookingDialog.hidden) closeBookingDialog();else if(!lightbox.hidden) closeLightbox();else if(!mobileNav.hidden)closeMobile();else $('#langPopover').hidden=true;}
    if (!lightbox.hidden&&event.key==='ArrowLeft')$('#lightboxPrev').click();
    if (!lightbox.hidden&&event.key==='ArrowRight')$('#lightboxNext').click();
  });

  // Progressive reveal effects, no-JS fallback is handled by noscript in HTML.
  if ('IntersectionObserver' in window) {
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target);}}),{threshold:.10,rootMargin:'0px 0px 45px 0px'});
    $$('.reveal').forEach(node=>observer.observe(node));
  } else {$$('.reveal').forEach(node=>node.classList.add('visible'));}
})();
