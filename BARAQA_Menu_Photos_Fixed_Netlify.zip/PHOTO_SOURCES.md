# BARAQA — კერძების ფოტოების წყაროები / Food photo sources

This menu uses 67 distinct, item-specific photographic links from Wikimedia Commons and owner-provided photos. There are 21 food-related items without a verified photographic match; they display a branded dish-specific illustration if no photo exists. Drink categories use designed typographic cards, not photos.

**Important for commercial use:** The linked Commons files have individual copyright licenses. Before publishing, review each linked file page for the author, permitted uses, attribution wording, a license link, and any share-alike requirements. Attribution and modification notices may be required. The menu links to the source page under each image, but those links alone may not satisfy every license. **The website retrieves Commons photos over the internet; they are not embedded into the ZIP. Since October 2026 it uses Wikimedia’s official `Special:Redirect/file` endpoint to improve image loading.**

The Commons photographs are **illustrative**, not proof of the exact presentation of dishes prepared at Baraqa. Signature Baraqa items should use genuine owner photos.

## Curated photos / შერჩეული ფოტოები

| Category | Dish | Image source |
|---|---|---|
| Starters | Georgian cheese assortment | [Source](https://commons.wikimedia.org/wiki/File:Georgian_cheese_in_%D0%A2bilisi_shop.jpg) |
| Starters | Sulguni cheese | [Source](https://commons.wikimedia.org/wiki/File:Discs-of-sulguni-cheese.jpg) |
| Starters | Imeretian cheese | [Source](https://commons.wikimedia.org/wiki/File:Mchadi_and_Imeretian_cheese.jpg) |
| Starters | Pickled vegetables | [Source](https://commons.wikimedia.org/wiki/File:Mzhavis_asorti_(%E1%83%9B%E1%83%9F%E1%83%90%E1%83%95%E1%83%98%E1%83%A1_%E1%83%90%E1%83%A1%E1%83%9D%E1%83%A0%E1%83%A2%E1%83%98).JPG) |
| Starters | Eggplant with walnuts | [Source](https://commons.wikimedia.org/wiki/File:Eggplant_with_walnut_and_pomegranate_seeds.jpg) |
| Starters | Ajapsandali | [Source](https://commons.wikimedia.org/wiki/File:Ajapsandali_-_Georgian_eggplant_stew.jpg) |
| Salads | Cucumber and tomato salad | [Source](https://commons.wikimedia.org/wiki/File:Traditional_Georgian_salad.jpg) |
| Salads | Cucumber and tomato salad with walnuts | [Source](https://commons.wikimedia.org/wiki/File:Traditional_Georgian_salad_with_walnuts.jpg) |
| Salads | Vegetable salad | [Source](https://commons.wikimedia.org/wiki/File:Georgian_salad.jpg) |
| Salads | Caesar salad | [Source](https://commons.wikimedia.org/wiki/File:A_Caesar_salad.jpg) |
| Salads | Greek salad | [Source](https://commons.wikimedia.org/wiki/File:Greek_Salad_from_Thessaloniki.jpg) |
| Salads | Chicken salad | [Source](https://commons.wikimedia.org/wiki/File:Chicken_salad_on_striped_tablecloth.jpg) |
| Salads | Mushroom salad | [Source](https://commons.wikimedia.org/wiki/File:Mushroom_salad_2020.jpg) |
| Salads | Crab salad | [Source](https://commons.wikimedia.org/wiki/File:Crab_and_avocado_salad.jpg) |
| Soups | Chicken soup | [Source](https://commons.wikimedia.org/wiki/File:Chicken_soup_homemade.jpg) |
| Soups | Chikhirtma | [Source](https://commons.wikimedia.org/wiki/File:Chikhirtma.jpg) |
| Soups | Kharcho soup | [Source](https://commons.wikimedia.org/wiki/File:Kharcho_meat_soup.jpg) |
| Soups | Vegetable soup | [Source](https://commons.wikimedia.org/wiki/File:Argentine_Homemade_Vegetable_Soup.jpg) |
| Soups | Mushroom soup | [Source](https://commons.wikimedia.org/wiki/File:Mushroom_Soup.jpg) |
| Soups | Fish soup | [Source](https://commons.wikimedia.org/wiki/File:Fish_soup.jpg) |
| Georgian Pastries | Imeretian khachapuri | [Source](https://commons.wikimedia.org/wiki/File:Khachapuri_1.jpg) |
| Georgian Pastries | Adjarian khachapuri | [Source](https://commons.wikimedia.org/wiki/File:Adjarian_khachapuri_on_a_wooden_tray.jpg) |
| Georgian Pastries | Lobiani | [Source](https://commons.wikimedia.org/wiki/File:Lobiani_-_bean-filled_bread.jpg) |
| Georgian Pastries | Megrelian khachapuri | [Source](https://commons.wikimedia.org/wiki/File:Megruli_Chatschapuri.jpg) |
| Georgian Pastries | Kubdari | [Source](https://commons.wikimedia.org/wiki/File:Kubdari_meat_pastry.jpg) |
| Georgian Pastries | Mchadi | [Source](https://commons.wikimedia.org/wiki/File:Mchadi_2.jpg) |
| Georgian Pastries | Bread | [Source](https://commons.wikimedia.org/wiki/File:%D0%A8%D0%BE%D1%82%D0%B8_%D0%B3%D1%80%D1%83%D0%B7%D0%B8%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%85%D0%BB%D0%B5%D0%B1.jpg) |
| Pizza | Pizza Margherita | [Source](https://commons.wikimedia.org/wiki/File:Pizza_Margherita.jpg) |
| Pizza | Vegetable pizza | [Source](https://commons.wikimedia.org/wiki/File:Vege_pizza.jpg) |
| Main Courses | Khinkali (beef and pork) | Owner-provided image |
| Main Courses | Khinkali with mushroom or cheese | [Source](https://commons.wikimedia.org/wiki/File:Khinkali_cheese.jpg) |
| Main Courses | Veal chashushuli | [Source](https://commons.wikimedia.org/wiki/File:Chashushuli_01.jpg) |
| Main Courses | Pork ojakhuri | [Source](https://commons.wikimedia.org/wiki/File:Ojakhuri.JPG) |
| Main Courses | Veal ojakhuri | [Source](https://commons.wikimedia.org/wiki/File:Odjakhuri_-_Georgian_(Kartvelian)_dish_with_meat._Served_in_Galaktioni_restaurant_Istanbul.jpg) |
| Main Courses | Chicken chakhokhbili with walnuts | [Source](https://commons.wikimedia.org/wiki/File:Chakhokhbili_Closeup.jpg) |
| Main Courses | Mushrooms with sulguni in a clay pot | [Source](https://commons.wikimedia.org/wiki/File:Georgian_Cheese-Stuffed_Mushrooms.jpg) |
| Main Courses | Beef tongue with garlic and chili pepper | [Source](https://commons.wikimedia.org/wiki/File:Homemade_beef_tongue.jpg) |
| Main Courses | Fried chicken (Tabaka) | [Source](https://commons.wikimedia.org/wiki/File:Chicken_tabaka.jpg) |
| Main Courses | Chkmeruli | Owner-provided image |
| Main Courses | Kupati | [Source](https://commons.wikimedia.org/wiki/File:Kupati_(%E1%83%99%E1%83%A3%E1%83%9E%E1%83%90%E1%83%A2%E1%83%98).JPG) |
| Main Courses | Megrelian satsivi | [Source](https://commons.wikimedia.org/wiki/File:Satsivi_(2).jpg) |
| Main Courses | Omelette with signature sausage | [Source](https://commons.wikimedia.org/wiki/File:Breakfast_Omelette.jpg) |
| Main Courses | Beans in a clay pot | [Source](https://commons.wikimedia.org/wiki/File:Lobio_in_clay_pots_covered_with_mchadi.jpg) |
| Main Courses | Gomi | [Source](https://commons.wikimedia.org/wiki/File:Ghomi_with_Georgian_Cheese_Sulguni.jpg) |
| Main Courses | Elarji | [Source](https://commons.wikimedia.org/wiki/File:Elarji_-_cornmeal_and_sulguni_cheese.jpg) |
| Main Courses | Hot salmon and vegetable salad | [Source](https://commons.wikimedia.org/wiki/File:Next_Door_roasted_veggie_salad_with_salmon.jpg) |
| From the Grill | Grilled pork | [Source](https://commons.wikimedia.org/wiki/File:Ghoris_Mtsvadi_(%E1%83%A6%E1%83%9D%E1%83%A0%E1%83%98%E1%83%A1_%E1%83%9B%E1%83%AC%E1%83%95%E1%83%90%E1%83%93%E1%83%98).JPG) |
| From the Grill | Grilled chicken | [Source](https://commons.wikimedia.org/wiki/File:Chicken_Mtsvadi_and_Fried_Piglet.jpg) |
| From the Grill | Grilled salmon | [Source](https://commons.wikimedia.org/wiki/File:Grilled_salmon_garnished_with_lemon_and_parsley.jpg) |
| From the Grill | Grilled vegetables | [Source](https://commons.wikimedia.org/wiki/File:Grilled_vegetables_(2).jpg) |
| From the Grill | Kebab | [Source](https://commons.wikimedia.org/wiki/File:Mtsvadi.jpg) |
| Side Dishes | Rice | [Source](https://commons.wikimedia.org/wiki/File:Cooked_Rice_2.jpg) |
| Side Dishes | French fries | [Source](https://commons.wikimedia.org/wiki/File:French_Fries.jpg) |
| Side Dishes | Mexican-style potatoes | Owner-provided image |
| Sauces | Tkemali (sour plum sauce) | [Source](https://commons.wikimedia.org/wiki/File:Tkemali_2.jpg) |
| Sauces | Tomato sauce | [Source](https://commons.wikimedia.org/wiki/File:Pasta_sauce_in_a_bowl.webp) |
| Sauces | Adjika (spicy pepper sauce) | [Source](https://commons.wikimedia.org/wiki/File:Megrelian_ajika.jpg) |
| Sauces | Sour cream | [Source](https://commons.wikimedia.org/wiki/File:Sour_Cream.jpg) |
| Sauces | Bazhe (walnut sauce) | [Source](https://commons.wikimedia.org/wiki/File:Satsivi_al_Batumi_Val%C3%A8ncia.jpg) |
| Sauces | Mayonnaise | [Source](https://commons.wikimedia.org/wiki/File:Mayonnaise_in_the_bowl.jpg) |
| Sauces | Ketchup | [Source](https://commons.wikimedia.org/wiki/File:Homemade_ketchup_canned_(4156502791).jpg) |
| Desserts | Chocolate crepe | [Source](https://commons.wikimedia.org/wiki/File:Chocolate_crepe_layered_with_chocolate_mousse_with_puffed_sorghum_and_molasses_syrup_(18705305753).jpg) |
| Desserts | Chocolate and banana crepe | [Source](https://commons.wikimedia.org/wiki/File:Banana_%2B_Chocolate_cr%C3%AApe_%40_Breakfast_%40_Le_Resto_du_Village_%40_Montr%C3%A9al_(30461563936).jpg) |
| Desserts | Crepe with cottage cheese, sour cream and raisins | [Source](https://commons.wikimedia.org/wiki/File:Veselka-nalysnyky-20250309_195201.jpg) |
| Desserts | Apple pie with walnuts and raisins | [Source](https://commons.wikimedia.org/wiki/File:2013-365-222_Mmmmm_Pie_(9481459925).jpg) |
| Desserts | Honey | [Source](https://commons.wikimedia.org/wiki/File:Dipper_stick_and_honey_in_a_jar.jpg) |
| Desserts | Vanilla or chocolate ice cream | [Source](https://commons.wikimedia.org/wiki/File:20220727-_pic_of_double_icecream_with_chocolate_and_vanilla.jpg) |

## Items awaiting a suitable photo / შესავსები ფოტოები

- Soups: Tatariakhni
- Georgian Pastries: Adjarian khachapuri with beans
- Georgian Pastries: Adjarian khachapuri with ajapsandali
- Georgian Pastries: Lobiani with smoked ham
- Georgian Pastries: Signature Baraqa khachapuri
- Georgian Pastries: Chvishtari
- Georgian Pastries: Bread basket
- Pizza: Signature Baraqa pizza
- Pizza: Baraqa pizza with signature sausage
- Main Courses: Veal roasted in a clay pot
- Main Courses: Chicken or mushroom chashushuli
- Main Courses: Mushroom ojakhuri
- Main Courses: Chicken ojakhuri
- Main Courses: Mushrooms in a clay pot
- Main Courses: Iahni
- Main Courses: Chizhi-bizhi
- Main Courses: Chizhi-bizhi with chicken and cheese
- Main Courses: Fried sulguni with mint
- Main Courses: Hot chicken and sulguni salad
- Main Courses: Signature Sun khachapuri
- From the Grill: Kebab with sulguni cheese
