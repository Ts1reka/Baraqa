// მენიუს მონაცემები გადმოტანილია მომხმარებლის მიერ მოწოდებული ფოტოსურათებიდან.
// price: null ნიშნავს, რომ ფოტოზე ფასი საკმარისად მკაფიოდ არ ჩანს.
window.BARAQA_MENU = [
 {id:'starters',ka:'სტარტერები',en:'Starters',items:[
 ['ქართული ყველის ასორტი','Georgian cheese assortment',25,'იმერული, სულგუნი და შებოლილი სულგუნი','Imeretian, sulguni and smoked sulguni'],
 ['სულგუნი','Sulguni cheese',18],['იმერული ყველი','Imeretian cheese',15],
 ['მწნილის ასორტი','Pickled vegetables',null,'ჯონჯოლი, კიტრი, ნიორი, წიწაკა','Jonjoli, cucumber, garlic and pepper'],
 ['ნიგვზიანი ბადრიჯანი','Eggplant with walnuts',null,'ნიგოზი, ქინძი და სანელებლები','Walnut, coriander and spices'],
 ['აჯაფსანდალი','Ajapsandali',13,'ბოსტნეულის ტრადიციული კერძი','Traditional vegetable stew']]},
 {id:'salads',ka:'სალათები',en:'Salads',items:[
 ['კიტრისა და პომიდვრის სალათი','Cucumber and tomato salad',9],
 ['კიტრისა და პომიდვრის სალათი ნიგვზით','Cucumber and tomato salad with walnuts',11],
 ['ბოსტნეულის სალათი','Vegetable salad',15],['ცეზარის სალათი','Caesar salad',20],
 ['ბერძნული სალათი','Greek salad',20],['ქათმის სალათი','Chicken salad',15],
 ['სოკოს სალათი','Mushroom salad',15],['კრაბის სალათი','Crab salad',15]]},
 {id:'soups',ka:'წვნიანები',en:'Soups',items:[
 ['ქათმის წვნიანი','Chicken soup',17],['ჩიხირთმა','Chikhirtma',18,'ქათამი, კვერცხი, ლიმონი და ქინძი','Chicken, egg, lemon and coriander'],
 ['სუპ-ხარჩო','Kharcho soup',18,'საქონლის ხორცი, ბრინჯი, პომიდორი და მწვანილი','Beef, rice, tomato and herbs'],
 ['თათარიახნი','Tatariakhni',18,'საქონლის ბულიონი მწვანილითა და სანელებლებით','Beef broth with herbs and spices'],
 ['ბოსტნეულის სუპი','Vegetable soup',15],['სოკოს სუპი','Mushroom soup',15],['თევზის სუპი','Fish soup',22]]},
 {id:'bakery',ka:'ცომეული',en:'Georgian Pastries',items:[
 ['იმერული ხაჭაპური','Imeretian khachapuri',15],['აჭარული ხაჭაპური','Adjarian khachapuri',17],
 ['აჭარული ხაჭაპური ლობიანით','Adjarian khachapuri with beans',16],
 ['აჭარული ხაჭაპური აჯაფსანდალით','Adjarian khachapuri with ajapsandali',18],
 ['ლობიანი','Lobiani',13],['ლობიანი ლორით','Lobiani with smoked ham',17],
 ['საფირმო ხაჭაპური „ბარაქა“','Signature Baraqa khachapuri',26,'სულგუნითა და იმერული ყველით','With sulguni and Imeretian cheese'],
 ['მეგრული ხაჭაპური','Megrelian khachapuri',22],['კუბდარი','Kubdari',22,'ცომეული ხორცით','Meat-filled pastry'],
 ['მჭადი','Mchadi',2],['ჭვიშტარი','Chvishtari',10],['პურის კალათა','Bread basket',6],['პური','Bread',4]]},
 {id:'pizza',ka:'პიცა',en:'Pizza',items:[
 ['საფირმო პიცა „ბარაქა“','Signature Baraqa pizza',25,'ლორით ან ქათმით','With ham or chicken'],
 ['პიცა „ბარაქა“ საფირმო ძეხვით','Baraqa pizza with signature sausage',27,'მოცარელას ყველით','With mozzarella cheese'],
 ['პიცა მარგარიტა','Pizza Margherita',24],['პიცა ბოსტნეულით','Vegetable pizza',null]]},
 {id:'mains',ka:'ძირითადი კერძები',en:'Main Courses',items:[
 ['ხინკალი','Khinkali (beef and pork)',1.75,'ფასი 1 ცალზე','Price per piece'],
 ['ხინკალი სოკოთი ან ყველით','Khinkali with mushroom or cheese',1.60,'ფასი 1 ცალზე','Price per piece'],
 ['ხბოს მწვადი კეცზე','Veal roasted in a clay pot',30],
 ['ხბოს ჩაშუშული','Veal chashushuli',26],['ჩაშუშული ქათმით ან სოკოთი','Chicken or mushroom chashushuli',22],
 ['ღორის ოჯახური','Pork ojakhuri',25],['ხბოს ოჯახური','Veal ojakhuri',26],
 ['სოკოს ოჯახური','Mushroom ojakhuri',21],['ქათმის ოჯახური','Chicken ojakhuri',21],
 ['ქათმის ჩახოხბილი ნიგვზით','Chicken chakhokhbili with walnuts',23],
 ['სოკო კეცზე','Mushrooms in a clay pot',20],['სოკო სულგუნით კეცზე','Mushrooms with sulguni in a clay pot',24],
 ['საქონლის ენა ნივრითა და წიწაკით','Beef tongue with garlic and chili pepper',25],
 ['ტაბაკა','Fried chicken (Tabaka)',30],['სოფლის ქათამი შქმერულად','Chkmeruli',35,'ქათამი ნივრის სოუსში','Chicken in garlic sauce'],
 ['იახნი','Iahni',28,'ხბოს ხორცი ნიგვზის სოუსით','Veal in walnut sauce'],
 ['კუპატი','Kupati',18,'ტრადიციული ღორის ძეხვი','Georgian pork sausage'],
 ['დედლის საცივი მეგრულად','Megrelian satsivi',38,'ქათამი ნიგვზის სოუსში','Chicken in walnut sauce'],
 ['ჩიჟი-ბიჟი','Chizhi-bizhi',17,'პომიდორი, კვერცხი, ხახვი, წიწაკა და სულგუნი','Tomato, egg, onion, pepper and sulguni'],
 ['ჩიჟი-ბიჟი ქათმითა და ყველით','Chizhi-bizhi with chicken and cheese',20],
 ['შემწვარი სულგუნი კეცზე პიტნით','Fried sulguni with mint',19],
 ['ომლეტი საფირმო ძეხვით','Omelette with signature sausage',17],
 ['ლობიო ქოთანში','Beans in a clay pot',8],['ღომი','Gomi',6,'სიმინდის ტრადიციული ფაფა','Traditional cornmeal porridge'],
 ['ელარჯი','Elarji',8,'ღომი სულგუნით','Cornmeal with sulguni'],
 ['ცხელი სალათი ქათმითა და სულგუნით','Hot chicken and sulguni salad',28],
 ['საფირმო ხაჭაპური „მზე“','Signature Sun khachapuri',30,'სულგუნითა და იმერული ყველით','Sulguni and Imeretian cheese'],
 ['ცხელი სალათი ორაგულით','Hot salmon and vegetable salad',30]]},
 {id:'grill',ka:'გრილზე მომზადებული',en:'From the Grill',items:[
 ['ღორის მწვადი','Grilled pork',19],['ქათმის მწვადი','Grilled chicken',17],
 ['ორაგულის მწვადი','Grilled salmon',32],['ბოსტნეულის მწვადი','Grilled vegetables',18],
 ['ქაბაბი','Kebab',18],['ქაბაბი სულგუნით','Kebab with sulguni cheese',20]]},
 {id:'sides',ka:'გარნირი',en:'Side Dishes',items:[
 ['ბრინჯი','Rice',8],['კარტოფილი ფრი','French fries',8],['მექსიკური კარტოფილი','Mexican-style potatoes',15]]},
 {id:'sauces',ka:'სოუსები',en:'Sauces',items:[
 ['ტყემალი','Tkemali (sour plum sauce)',3],['ტომატის საწებელი','Tomato sauce',3],
 ['აჯიკა','Adjika (spicy pepper sauce)',6],['არაჟანი','Sour cream',5],
 ['ბაჟე','Bazhe (walnut sauce)',13],['მაიონეზი','Mayonnaise',5],['კეტჩუპი','Ketchup',3]]},
 {id:'desserts',ka:'დესერტები',en:'Desserts',items:[
 ['კრეპი შოკოლადით','Chocolate crepe',10],['კრეპი შოკოლადით და ბანანით','Chocolate and banana crepe',15],
 ['კრეპი ხაჭოთი, არაჟნით და ქიშმიშით','Crepe with cottage cheese, sour cream and raisins',13],
 ['ვაშლის ღვეზელი ნიგვზით და ქიშმიშით','Apple pie with walnuts and raisins',5],
 ['თაფლი','Honey',6],['ნაყინი ვანილით ან შოკოლადით','Vanilla or chocolate ice cream',7]]},
 {id:'soft',ka:'გამაგრილებელი სასმელები',en:'Soft Drinks',items:[
 ['წყაროს წყალი','Spring water',2.5],['მინერალური წყალი','Sparkling water',4],
 ['ლიმონათი','Lemonade',4],['კოკა-კოლა','Coca-Cola',null],['კოკა-კოლა ზერო','Coca-Cola Zero',null],
 ['ფანტა','Fanta',null],['საფირმო ლიმონათი','Signature lemonade',6],
 ['ხილის წვენი (250 მლ)','Fruit juice (250 ml)',5],['ხილის წვენი (1 ლ)','Fruit juice (1 L)',15],
 ['ახლად გამოწურული ფორთოხლის წვენი','Fresh orange juice',12],
 ['ცივი ჩაი ლიმონით და პიტნით','Iced tea with lemon and mint',7]]},
 {id:'coffee',ka:'ყავა',en:'Coffee',items:[
 ['ამერიკანო','Americano',5],['ესპრესო','Espresso',4],['კაპუჩინო','Cappuccino',6],
 ['ლატე','Caffè latte',9],['ცივი ყავა','Iced coffee',8],
 ['ცივი ყავა ნაყინით','Iced coffee with ice cream',12],['თურქული ყავა','Turkish coffee',4]]},
 {id:'tea',ka:'ჩაი',en:'Tea',items:[
 ['ჩაი (შავი / მწვანე / ხილის)','Tea (black / green / fruit)',4],
 ['დასაყენებელი ჩაი (ჩაიდანი)','Tea pot (black / green / fruit)',8]]},
 {id:'beer',ka:'ლუდი',en:'Beer',items:[
 ['ნატახტარი ჩამოსასხმელი','Natakhtari draft beer',7],['კარვა','Karva',8],
 ['ლეფე','Leffe',8],['ლოვენბრაუ','Löwenbräu',8],['სტელა','Stella',9],
 ['ეფესი','Efes',9],['სტაროპრამენი','Staropramen',8],['კორონა','Corona',9],['ტაატი','Taati',9]]}
];
